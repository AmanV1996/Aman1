import javax.script.Bindings;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.scripting.sightly.pojo.Use;
import org.apache.sling.api.resource.ValueMap;


public class Color implements Use {

    private ValueMap page;
    private ValueMap page1;

    @Override
    public void init(Bindings bindings) {

        ResourceResolver resourceResolver = (ResourceResolver)bindings.get("resolver");
        page = resourceResolver.getResource("/apps/HTL").getValueMap();
        page1 = resourceResolver.getResource("/content/HtlAssignment").getValueMap();
    }
    
    public ValueMap getPage() {
        return this.page;
    }
    
     public ValueMap getPage1() {
        return this.page1;
    }
}